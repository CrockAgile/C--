#include <iostream>

using namespace std;

//void foo(int x){
//    cout << "foo is " << x << endl;
//}

int x;

int main()
{
    int **c[3][2], **y[2];
    {
        int x;
        {
            int x;
        }
    }
    {
        int x;
    }
}
