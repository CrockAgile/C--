#include <iostream>
#include <cstdlib>
using namespace std;


int x = 12;

int main ()
{

    if ( x < 12 )
         ;
    if ( x < 17 )
         ;
    if ( x < 122 )
         ;
    if ( x < 20000 )
         ;



    if ( x < 12 )
         ;
    else if ( x < 17 )
         ;
    else if ( x < 122 )
         ;
    else if ( x < 20000 )
         ;

}
