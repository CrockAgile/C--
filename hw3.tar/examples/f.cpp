void f(int p)
{
   p = p+1;
}
