#include <iostream>
using namespace std;
int main()
{
	int x = 15;
	cout << "------------------------------------------" << endl;
	cout << "|  this |  is  |  " << x << "  | what | I | meant |" << endl;
	cout << "------------------------------------------" << endl;
}
