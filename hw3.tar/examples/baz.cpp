#include <iostream>
using namespace std;

int y;

int main()
{
  int x;
  cout << "helo" << endl;
  cin >> x;
  if (x > 2) {
    cout << "goodbye";
  }
}
