/* semantics.c
 * jeff crocker
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "semantics.h"

void* sem_malloc(int size, bool zero) {
    void* new;
    zero ? (new = calloc(1,size)) : (new = malloc(size));
    if (!new){
        fprintf(stderr,"Memory allocation failed in Semantic Analysis\n");
        exit(3);
    }
    return new;
}

/* TYPES AND ENVIRONS SECTION */

// hash with mod specific to semantic tables
unsigned long env_hash(char *s) {
    unsigned long hash = 5381;
    int c;
    while( (c = *s++) )
        hash = ((hash << 5) + hash) + c;
    return hash % S_SIZE;
}


type_el* mk_type_el(btype t, type_el *s, type_el *n) {
    type_el *new = sem_malloc(sizeof(type_el),0);
    new->type = t; new->sub = s; new->next = n;
    return new;
}

// lisp flashbacks
void free_type_list(type_el* head) {
    type_el *prev, *curr = head;
    type_el *subp, *subc = head->sub;
    while( (prev = curr) ) {
        curr = curr->next;
        while( (subp = subc) ) {
            subc = subc->next;
            free(subp);
        }
        free(prev);
    }
}

table_el* mk_table_el(token *t, type_el *ty, environ *p, table_el *n) {
    table_el *new = sem_malloc(sizeof(table_el),1);
    new->tok = t; new->type = ty; new->par_env = p; new->next = n;
    // other elements zeroed from calloc
    return new;
}

void free_table_list(table_el *head) {
    table_el *prev, *curr = head;
    while ( (prev = curr) ) {
        curr = curr->next;
        // tokens are freed in parse cleanup
        free_type_list(prev->type);
        free_type_list(prev->param_types);
        free_environ(prev->chl_env);
    }
}

environ* mk_environ(environ *parent, int depth) {
    environ *new = sem_malloc(sizeof(environ),1);
    new->locals = sem_malloc(S_SIZE * sizeof(table_el*),1);
    new->up = parent;
    new->ksize = ENV_KIDS;
    new->depth = depth;
    new->kids = sem_malloc(ENV_KIDS * sizeof(environ*),1);
    return new;
}

table_el* environ_lookup(environ *e, char *key) {
    table_el* res = e->locals[env_hash(key)];
    if (res) {
        while (res->next) {
            if (strcmp(key,res->tok->text)) {
                return res;
            }
            res = res->next;
        }
    }
    return NULL;
}

bool environ_insert(environ *e, token *to, btype ty, bool c, bool d) {
    unsigned long index = env_hash(to->text);
    table_el** des = &(e->locals[index]);
    // if already in table, error
    if (environ_lookup(e,to->text)) {
        fprintf(stderr,"Double declaration of %s\n",to->text);
        exit(3);
    }
    // make new type list
    type_el* newtype = sem_malloc(sizeof(type_el),1);
    newtype->type = ty;
    // make new table element
    table_el* new = sem_malloc(sizeof(table_el),1);
    new->tok = to;
    new->type = newtype;
    new->cons = c; new->defd = d;
    // prepend to list of hash collisions
    new->next = *des;
    *des = new;
    return 1;
}

bool add_env_child(environ *parent) {
    if  (!parent)
        return 0;

    if ( parent->nkids < parent->ksize ) { // under max size
        parent->nkids++;
        parent->kids[parent->nkids] = mk_environ(parent,parent->depth + 1);
    }
    else { // grow the array
        short old_size = parent->ksize;
        short new_size = old_size * 2; // double in size
        // really should put a ceiling on size TODO
        environ **old = parent->kids;
        environ **new = sem_malloc(new_size * sizeof(environ*),1);
        memcpy(new,old,old_size * sizeof(environ*));
        parent->ksize = new_size;
        free(parent->kids);
        parent->kids = new;
    }
    return 1;
}

void free_environ(environ *target) {
    int i;
    short nkids;
    environ *child;
    for (i=0; i<S_SIZE; i++)
        free_table_list(target->locals[i]);
    // dont free parent, handled in tree traversal
    nkids = target->nkids; // save for future compares
    for (i=0; i<nkids; i++) {
        child = target->kids[i];
        if (child) {
            free_environ(child);
        }
    }
    // now that all taken indexes freed
    free(target->kids);
}

environ* GetGlobal() {
    if (GlobalEnviron) // singleton?
        return GlobalEnviron;
    // 'GLOBAL' environ is special case environ
    // that has no parent, i.e. root
    return mk_environ(NULL,0);
}

environ* CurrEnv() {
    if (curr_env)
        return curr_env;
    curr_env = GetGlobal();
    return curr_env;
}

void PrintCurrEnv() {
    int i;
    for (i=0; i<S_SIZE; i++) {
    }
}

void PushCurrEnv() {
    env_el *new = sem_malloc(sizeof(env_el),0);
    new->env = curr_env;
    new->next = env_stack;
    env_stack = new;
}

environ* PopEnv() {
    env_el* del = env_stack;
    env_stack = env_stack->next;
    environ *res = del->env;
    free(del);
    return res;
}

/* TREE TRAVERSALS SECTION */

void preorder_semantics(struct prodrule *p){
}

void postorder_semantics(struct prodrule *p){
}

void semantic_traversal(struct pnode *p) {
    struct prodrule *curr; int i;
    if(!p) return;
    // prodrules are maintained in linked list
    for (curr=p->prule; curr; curr=curr->next)
        preorder_semantics(curr);

    for (i = 0; i < p->nkids; i++)
        semantic_traversal(p->kids[i]);

    for (curr=p->prule; curr; curr=curr->next)
        postorder_semantics(curr);
}
