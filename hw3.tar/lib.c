#include "lex.c"
#include "parse.c"
#include "semantics.c"
