#include <iostream>
using namespace std;

#include "Groo.h"

int main()
{
   Groo g;
   cout << g.getmyval() << endl;
}
