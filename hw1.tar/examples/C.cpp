// #include "A.h" not needed here, B.h include it
#include     <iostream>
#include "B.h"
int main()
{
    "foobar";
    Foo a = new foo;
}
