class Groo {
private:
   int myval;

public:
   Groo();
   int getmyval();
   void dostuff();
};
