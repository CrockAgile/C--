TODO advanced lexerr
    - Line numbers
    - characters
    - more specific?

TODO 'c' string functionality ?

TODO 'aaa'

TODO built in buffer state stack

TODO decide how to limit string length


added ssh configuration ?
