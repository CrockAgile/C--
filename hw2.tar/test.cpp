 
#include <iostream>

typedef struct grog { };

class baz {
public:
    void grock(char*);
    int x;
}

void foo();

int main(int argc, char** argv) {
    int x = 1;
}
