int main() {
    foo(7);
}
