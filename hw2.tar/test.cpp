 
#include <iostream>

typedef struct grog { 
    int foo;
} something;

class baz {
public:
    void grock(int x);
    int x;
};

class bat {
public:
    void stuff();
    int y;
};
