#include <iostream>
using namespace std;
int main()
{
   float d, d2;
   cout << "enter a number: ";
   cin >> d;
   d2 = 5.3 / d;
   cout << d2 << endl;
   cout << "\nnow, for integers" << endl;

   int i, i2;
   cout << "enter a number: ";
   cin >> i;
   i2 = 5.3 / i;
   cout << i2 << endl;
   cout << "that's all folks" << endl;


}
