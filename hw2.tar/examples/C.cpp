// #include "A.h" not needed here, B.h include it
#include "B.h"
int main()
{
}
