class A {
private:
   int x, y, z;
public:
   // given a scale, return the sum of the scaled components
   double scaledsum(double);
   };
