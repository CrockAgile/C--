
int main(){

    "This is /*not a comment*/"
    /* This is a comment  */
    /* C++ does not support /* nested comments */ */
    /* This also contains a //nested comment */
    
    "Keep this string" // this is a comment "//... "
    "This // is not a comment... "
    KEEPTHIS; // Another comment
    x = 1; // Also a comment, after x = 1;  
    return 0; 
}


