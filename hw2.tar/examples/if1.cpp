#include <iostream>
using namespace std;

int main()
{
   double d = 0.0;
   d++;
   cout << d << endl;
}
