#include "A.h"

class B {
private:
   double scale;
   A a[3][5];
public:
   // calculate the sum of applying my scale to all my elements
   double calc();
   };
