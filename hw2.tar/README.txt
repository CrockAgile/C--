Class long project for CS 445: Compiler Design

Last Edited: 10/7/2014

TODOs:
    Separate out dependencies (parse.h vs lex.h vs ??)
    
    Improve Lexical Errors
        - Line Numbers
        - Column Number, specific character
        - Expectations?

    Enforce Character Constants
        - 'c' vs 'cccc'

    Transition Lexer to Built-in Flex buffer state stack
        - Dynamic Buffer

    String Limitations (length)
