Class long project for CS 445: Compiler Design

TODO advanced lexerr
    - Line numbers
    - characters
    - more specific?

TODO 'c' string functionality ?

TODO 'aaa'

TODO built in buffer state stack

TODO decide how to limit string length


