#include <stdlib.h>
#include "semantics.h"

struct type *integerType = NULL;
struct type *boolType = NULL;
struct type *voidType = NULL;

// classic singletons?
struct type* IntegerType(){
    if ( integerType == NULL ) {
        integerType = (struct type*) malloc(sizeof(struct type));
        integerType->kind = int_type;
    }
    return integerType;
}

struct type* BooleanType(){
    if ( boolType == NULL ) {
        boolType = (struct type*) malloc(sizeof(struct type));
        boolType->kind = int_type;
    }
    return boolType;
}

struct type* VoidType(){
    if ( voidType == NULL ) {
        voidType = (struct type*) malloc(sizeof(struct type));
        voidType->kind = int_type;
    }
    return voidType;
}

