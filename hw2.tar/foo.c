#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lib.h"
int init_nametable() {
    nametable = (struct hash_el**)calloc(TABLESIZE,sizeof(struct hash_el*));
    if (!nametable)
        return 0;
    return 1;
}

// djb2 by Dan Bernstein
unsigned long hash_name(unsigned char *s) {
    unsigned long hash = 5381;
    int c;

    while( c = *s++ )
        hash = ((hash << 5) + hash) + c;

    return hash;
}

int insert_name(struct hash_el *new) {
    struct hash_el** des = &nametable[hash_name(new->t->lval)%TABLESIZE];
    if( *des ) {
        new->next = *des;
    }
    *des = new;
    return 1;
}
struct hash_el* lookup_name(char *search) {
    struct hash_el* res = nametable[hash_name(search)%TABLESIZE];
    if( res )
        return res;

    return NULL;
}
int main() {
    token baz = {101,strdup("YYTEXT"),13,strdup("a.cpp"),strdup("LVAL")};
    init_nametable();
    struct hash_el foo = { &baz, 303, NULL };
    unsigned long bar = hash_name(foo.t->lval);
    printf("%s -> %lu\n",(char*)foo.t->lval, bar);
    insert_name(&foo);
    printf("Hash lookup: %s\n",(char*)lookup_name("LVAL")->t->lval);
    free(baz.text);
    free(baz.filename);
    free(baz.lval);
    return 0;
}
