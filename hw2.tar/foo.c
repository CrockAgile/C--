#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lib.h"

int init_nametable() {
    nametable = (token_el**)calloc(TABLESIZE,sizeof(token_el*));
    if (!nametable)
        return 0;
    return 1;
}

// djb2 by Dan Bernstein
unsigned long hash_name(unsigned char *s) {
    unsigned long hash = 5381;
    int c;

    while( c = *s++ )
        hash = ((hash << 5) + hash) + c;

    return hash;
}

int insert_name(token *insert) {
    unsigned long foo = hash_name(insert->text);
    token_el** des = &nametable[foo%TABLESIZE];
    token_el* new = (token_el*)malloc(sizeof(token_el));
    new->t = insert;
    new->next = *des;
    *des = new;
    return 1;
}

token_el* lookup_name(char *search) {
    token_el* res = nametable[hash_name(search)%TABLESIZE];
    printf("looking for hash: %lu\n",hash_name(search));
    if( res )
        printf("FOUND\n");
        return res;

    return NULL;
}

int id_check(char* s, int code) {
    token_el* res = lookup_name(s);
    if( res ) {
        while( strcmp(s,res->t->text) ) {
            if( res->next ) {
                res = res->next;
            }
            else {
                return code;
            }
        }
    }
    else {
        return code;
    }
}

int main() {
    token baz = {101,strdup("YYTEXT"),13,strdup("a.cpp"),strdup("LVAL")};
    token ben = {202,strdup("YYTEXT"),11,strdup("b.cpp"),strdup("LVAL")};
    init_nametable();
    token_el foo = { &baz, NULL };
    token_el foo2 = { &ben, NULL };
    unsigned long bar = hash_name(foo.t->text);
    printf("%s -> %lu\n",(char*)foo.t->text, bar);
    insert_name(&baz);
    insert_name(&ben);
    token_el* stuff = lookup_name("YYTEXT");
    printf("Hash lookup: %s\n",(char*)stuff->t->lval);
    while( stuff ) {
        printf("%d\n", stuff->t->code);
        stuff = stuff->next;
    }
    free(baz.text);
    free(baz.filename);
    free(baz.lval);
    free(ben.text);
    free(ben.filename);
    free(ben.lval);
    return 0;
}
